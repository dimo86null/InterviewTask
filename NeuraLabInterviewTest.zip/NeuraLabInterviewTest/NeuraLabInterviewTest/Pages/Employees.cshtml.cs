﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using NeuraLabInterviewTest.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace NeuraLabInterviewTest.Pages
{
    public class EmployeesModel : PageModel
    {
        public List<Employee> Employees { get; set; }
        public List<Department> Departments { get; set; }
        public List<SelectListItem> DropdownList { get; set; }


        private readonly ApplicationDbContext _context;

        public EmployeesModel(ApplicationDbContext context)
        {
            _context = context;
        }


        public void OnGet()
        {
            
            Employees = new List<Employee>(_context.Employees.Include(e => e.Department)
                .ToList());

            //DropdownList = _context.Departments
            //    .Select(d => new SelectListItem
            //    {
            //        Value = d.Id.ToString(),
            //        Text = d.Name
            //    })
            //    .ToList();
        }
        public IActionResult OnPost()
        {
           
            Departments = new List<Department>(_context.Departments.ToList());
            var department = Departments.SingleOrDefault(d => d.Name == Request.Form["departmentName"]);
            Employee employee = new Employee(department);



            employee.FirstName = Request.Form["firstName"];
            employee.Lastname = Request.Form["lastname"];
            employee.Email = Request.Form["email"];
            


            _context.Employees.Add(employee);

            _context.SaveChanges();

            return RedirectToPage();
        }
        public IActionResult OnPostEdit(int id)
        {
            return RedirectToPage();
        }

        public IActionResult OnPostDelete(int id)
        {
            Employee employeeToDelete = _context.Employees.FirstOrDefault(e => e.Id == id);

            _context.Employees.Remove(employeeToDelete);

            _context.SaveChanges();

            return RedirectToPage();
        }
    }
}
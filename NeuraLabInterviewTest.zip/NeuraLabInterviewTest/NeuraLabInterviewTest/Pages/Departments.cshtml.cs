﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using NeuraLabInterviewTest.Models;

namespace NeuraLabInterviewTest.Pages
{
    public class DepartmentsModel : PageModel
    {

        public List<Department> Departments { get; set; } = new List<Department>();

        [BindProperty]
        public Department Department { get; set; }

        private readonly ApplicationDbContext _context;

        public DepartmentsModel(ApplicationDbContext context)
        {
            _context = context;
        }
        public void OnGet()
        {
            Departments = new List<Department>(_context.Departments.ToList());
        }
        public IActionResult OnPost()
        {
            var department = new Department();
            department.Name = Request.Form["departmentName"];
            department.Location = Request.Form["location"];

            _context.Departments.Add(department);

            _context.SaveChanges();

            return RedirectToPage();
        }

        public IActionResult OnPostEdit(int id)
        {
            return RedirectToPage();
        }


        public IActionResult OnPostDelete(int id)
        {
            Department departmentToDelete = _context.Departments.FirstOrDefault(d => d.Id == id);

            _context.Departments.Remove(departmentToDelete);

            _context.SaveChanges();

            return RedirectToPage();
        }

      
    }
}
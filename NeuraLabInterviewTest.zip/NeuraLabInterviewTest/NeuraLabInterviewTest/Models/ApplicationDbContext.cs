﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NeuraLabInterviewTest.Models
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Department> Departments { get; set; }
        public ApplicationDbContext(DbContextOptions options):base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Employee>()
               .HasOne(e => e.Department)               
               .WithMany(d => d.Employees)
               .HasForeignKey(e => e.DepartmentId)
               .IsRequired(true);

            builder.Entity<Department>()
               .HasMany(d => d.Employees)
               .WithOne(e => e.Department)
               .IsRequired(true)
               .HasForeignKey(e => e.DepartmentId)
               .IsRequired(true);

            base.OnModelCreating(builder);
        }

    }
}

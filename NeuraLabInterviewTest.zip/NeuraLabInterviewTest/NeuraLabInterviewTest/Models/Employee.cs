﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;


namespace NeuraLabInterviewTest.Models
{
    public class Employee
    {
       
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string FirstName { get; set; }

        [Required]
        [StringLength(100)]
        public string Lastname  { get; set; }

        [Required]
        [StringLength(100)]
        public string Email { get; set; }
       
        [Required]
        [ForeignKey( "DepartmentId")]
        public int DepartmentId { get; set; }

        public Department Department { get; set; }


        public DateTime DateOfJoining { get; set; }

        public Employee()
        {

        }

        public Employee(Department department)
        {
            Department = department;
            DepartmentId = department.Id;
        }

    }
}
